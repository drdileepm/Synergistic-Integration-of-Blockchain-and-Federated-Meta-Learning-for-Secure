# GHDO Framework – Geometric Deep Reinforcement Learning for Drug Design

This repository provides a reproducible research implementation for the paper:

**Geometric Deep Reinforcement Learning with Hierarchical Variational Autoencoders for De Novo Drug Design and Activity Optimization**

## Overview
The project implements the **Geo‑Hierarchical Drug Optimiser (GHDO)** framework combining:

- Multi‑stage Variational Autoencoders (MS‑VAE)
- Geometric Multi‑Discrete Soft Actor‑Critic (Geom‑SAC)
- Graph neural network–based interaction scoring
- Molecular generation and evaluation pipeline

The repository contains:
- Source code for model training
- Dataset preprocessing scripts
- Molecular generation pipeline
- Evaluation scripts
- Configuration files
- Example experiment runner

## Installation

Clone repository and install requirements:

```bash
pip install -r requirements.txt
```

## Running Experiments

Preprocess dataset:

```bash
python preprocess_dataset.py
```

Train GHDO model:

```bash
python train_model.py
```

Generate molecules:

```bash
python generate_molecules.py
```

Evaluate performance:

```bash
python evaluate_results.py
```

## Datasets

The experiments use public datasets:

- ZINC250k
- PDBbind

Dataset preprocessing scripts are included.

## Reproducibility

All scripts required to reproduce the experiments in the manuscript are included.
Configuration parameters are stored in the `config/` directory.

## License

MIT License