from rdkit import Chem
import random

def generate_molecule():
    smiles_list = [
        "CCO",
        "CCN",
        "CCC",
        "C1=CC=CC=C1"
    ]
    return random.choice(smiles_list)

if __name__ == "__main__":
    print("Generated Molecules:")
    for i in range(10):
        print(generate_molecule())