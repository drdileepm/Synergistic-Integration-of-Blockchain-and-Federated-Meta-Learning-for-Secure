# Dataset Instructions

Place the following datasets in this folder:

1. ZINC250k dataset
2. PDBbind dataset

Example structure:

data/
    zinc_raw.csv
    pdbbind_data/

Then run:

python preprocess_dataset.py